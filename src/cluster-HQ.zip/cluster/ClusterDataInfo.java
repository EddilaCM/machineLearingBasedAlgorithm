package cluster;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import weka.core.Instances;

/*
 * Training Data information for user and item.<br>
 * @author Huang Qi
 * 2017/9/18 11:40
 */
@SuppressWarnings("serial")
public class ClusterDataInfo extends Instances{
	
	public final static int userNum = 943;
	public final static int itemNum = 1682;
	public final static int channel_Len = 5;

	/*
	 * User training set
	 */
	public static int[][] userTraRatings;// The rating matrix for user training
	public static int[][] userTraRateInds;// The rating indices for user training
	public static int[] userTraDegree;// The degrees for user training
	public static double[] userTraTolRating;// The total ratings for user training
	public static double[] userTraAveRating;// The average ratings for user training
	public static double[][] userTraChannels = new double[userNum][channel_Len]; 
	public static double[][] userTraChanRate = new double[userNum][channel_Len];
	
	/*
	 * Item training set
	 */
	public static int[][] itemTraRatings;// The rating matrix for item training
	public static int[][] itemTraRateInds;// The rating indices for item training
	public static int[] itemTraDegree;// The degrees for item training
	public static double[] itemTraTolRating;// The total ratings for item training
	public static double[] itemTraAveRating;// The average ratings for item training
	public static double[][] itemTraChannels = new double[itemNum][channel_Len]; 
	public static double[][] itemTraChanRate = new double[itemNum][channel_Len];
	
	
	/*
	 * constructor
	 */
	public ClusterDataInfo(Instances paraInstances) throws  IOException, Exception {
		super(paraInstances);
	}//Of the first constructor
	
	public ClusterDataInfo(Reader paraReader) throws  IOException, Exception {
		super(paraReader);
	}//Of the second constructor
	

	/*
	 * set user training set
	 */
	public static void setUserTrainSet(String paraFileName) throws Exception{
		FileReader fileReader = new FileReader(paraFileName);
		ClusterDataInfo clusterDataInfo = new ClusterDataInfo(fileReader);
		fileReader.close();
		
		userTraRatings = new int[userNum][itemNum];
		userTraDegree = new int[userNum];
		userTraTolRating = new double[userNum];
		userTraAveRating = new double[userNum];

		int x, y, z = 0;

		for (int i = 0; i < clusterDataInfo.numInstances(); i++) {
			
			x = (int)clusterDataInfo.instance(i).value(0);
			y = (int)clusterDataInfo.instance(i).value(1);
			
			z = (int)clusterDataInfo.instance(i).value(2);

//			if (s.length() >= 2) {
//				z = Integer.parseInt(s.substring(1, s.length()));
//			} // Of if
//			if (s.length() == 1) {
//				z = Integer.parseInt(clusterDataInfo.instance(i).stringValue(2));
//
//			} // Of if
			
			//user rating
			userTraRatings[x][y] = z;
	
			//user Degree
			if (z > 1e-4) {
				userTraDegree[x]++;
				//user channel
				userTraChannels[x][z - 1]++;
			} // Of if
		
			//scoreSum of user
			userTraTolRating[x] += z;
			
		} // Of for i
		
		// averageScore,and channel rate
		for (int i = 0; i < userNum; i++) {
		
			if (userTraDegree[i] > 1e-6) {
				userTraAveRating[i] = (userTraTolRating[i] * 1.0) / userTraDegree[i];					
			} else {
				userTraAveRating[i] = 0;
			}
			
			for (int j = 0; j < channel_Len; j++) {
				userTraChanRate[i][j] = userTraChannels[i][j] / userTraDegree[i];
//				System.out.println("userTraChannels["+i+"]["+j+"]"+" = "+userTraChannels[i][j]+" , degree = " + userTraDegree[i]);
//				System.out.println("userTraChanRate["+i+"]["+j+"]"+" = " + userTraChanRate[i][j]);
			}//Of for j
			
		} // Of for i

		
	}//Of setUserTrainSet
	
	
	/*
	 * set item training set
	 */
	public static void setItemTrainSet(String paraFileName) throws Exception{
		FileReader fileReader = new FileReader(paraFileName);
		ClusterDataInfo clusterDataInfo = new ClusterDataInfo(fileReader);
		fileReader.close();

		
		itemTraRatings = new int[userNum][itemNum];
		itemTraDegree = new int[itemNum];
		itemTraTolRating = new double[itemNum];
		itemTraAveRating = new double[itemNum];

		int x, y, z = 0;

		for (int i = 0; i < clusterDataInfo.numInstances(); i++) {
			x = (int)clusterDataInfo.instance(i).value(0);
			y = (int)clusterDataInfo.instance(i).value(1);

		//  String s = clusterDataInfo.instance(i).stringValue(2);
			z = (int)clusterDataInfo.instance(i).value(2);
//			if (s.length() >= 2) {
//				z = Integer.parseInt(s.substring(1, s.length()));
//			} // Of if
//			if (s.length() == 1) {
//				z = Integer.parseInt(clusterDataInfo.instance(i).stringValue(2));
//			} // Of if
			
			//ratingMatrix
			itemTraRatings[x][y] = z;

			//item Degree
			if (z > 1e-4) {
				itemTraDegree[y]++;
				//item channel
				itemTraChannels[y][z - 1]++;
			} // Of if

			// scoreSum of item
			itemTraTolRating[y] += z;
		} // Of for i

		// averageScore of item
		for (int i = 0; i < itemNum; i++) {
			if (itemTraDegree[i] > 1e-6) {
				itemTraAveRating[i] = (itemTraTolRating[i] * 1.0) / itemTraDegree[i];
			} else {
				itemTraAveRating[i] = 0;
			}
			
			for (int j = 0; j < channel_Len; j++) {
				itemTraChanRate[i][j] = itemTraChannels[i][j] / itemTraDegree[i];
//				System.out.println("userTraChannels["+i+"]["+j+"]"+" = "+userTraChannels[i][j]+" , degree = " + userTraDegree[i]);
//				System.out.println("userTraChanRate["+i+"]["+j+"]"+" = " + userTraChanRate[i][j]);
			}//Of for j
		} // Of for i
		
	}//Of setUserTrainSet
	
	
	
	/**
	 ********************************** 
	 * build the Data Model.
	 * @throws Exception 
	 **********************************
	 */
	public static void buildDataModel() throws Exception {

		String tempTrainingFilename = "src/data/ratings.arff";

		setUserTrainSet(tempTrainingFilename);
		
		setItemTrainSet(tempTrainingFilename);
		
	}// Of buildDataModel

	/**
	 * Test the rating table.
	 * 
	 * @param args
	 */
	public static void main(String args[]) {

		System.out.println("Testing ClusterDataInfo!");

		try {
			buildDataModel();
		} catch (Exception ee) {
			ee.printStackTrace();
		}

		System.out.println("Testing end!");

	}// Of main

}
